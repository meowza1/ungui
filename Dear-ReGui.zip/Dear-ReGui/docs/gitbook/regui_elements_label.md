# Label

> Source: https://depso.gitbook.io/regui/elements/label

