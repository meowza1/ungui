# Wayback Machine

Wayback Machine 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

 
 
 

 
 
 Ask the publishers to restore access to 500,000+ books. 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

 
 
 
 
 
 
 
 Hamburger icon 
 An icon used to represent a menu that can be
 toggled by interacting with this icon. 
 
 
 
 

 
 
 
 Internet Archive logo 
 A line drawing of the Internet Archive headquarters
 building façade. 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 Web icon 
 An illustration of a computer
 application window 
 
 

 
 Wayback Machine 

 
 
 
 
 
 
 
 
 
 Texts icon 
 An illustration of an open book.
 
 
 
 

 
 Texts 

 
 
 
 
 
 
 
 
 
 Video icon 
 An illustration of two cells of a film
 strip. 
 
 

 
 Video 

 
 
 
 
 
 
 
 
 
 Audio icon 
 An illustration of an audio speaker.
 
 
 
 
 
 
 
 

 
 Audio 

 
 
 
 
 
 
 
 
 
 Software icon 
 An illustration of a 3.5" floppy
 disk. 
 
 
 

 
 Software 

 
 
 
 
 
 
 
 
 
 Images icon 
 An illustration of two photographs.
 
 
 

 
 Images 

 
 
 
 
 
 
 
 
 
 Donate icon 
 An illustration of a heart shape
 
 
 
 

 
 Donate 

 
 
 
 
 
 
 
 
 
 Ellipses icon 
 An illustration of text ellipses.
 
 
 

 
 More 

 
 
 
 
 
 
 
 
 
 
 
 
 
 Donate icon 
 An illustration of a heart shape 
 
 
 

 "Donate to the archive" 
 

 
 
 
 
 
 
 
 
 User icon 
 An illustration of a person's head and chest.
 
 
 
 
 
 Sign up 
 |
 Log in 
 
 
 

 
 
 
 
 
 Upload icon 
 An illustration of a horizontal line over an up
 pointing arrow. 
 
 

 Upload 
 
 
 
 
 
 Search icon 
 An illustration of a magnifying glass. 
 
 

 
 
 
 
 Search the Archive 
 
 
 
 
 
 Search icon 
 An illustration of a magnifying glass. 
 
 

 
 
 
 

 
 
 
 
 
 
 
 
 
 
### Internet Archive Audio

 
 
 Live Music
 Archive 
 
 Librivox
 Free Audio 
 
 
 
 
#### Featured

 
 
 All Audio 
 
 Grateful Dead 
 
 Netlabels 
 
 Old Time Radio 
 
 
 78 RPMs
 and Cylinder Recordings 
 
 
 
 
 
#### Top

 
 
 Audio Books
 & Poetry 
 
 Computers,
 Technology and Science 
 
 Music, Arts
 & Culture 
 
 News &
 Public Affairs 
 
 Spirituality
 & Religion 
 
 Podcasts 
 
 Radio News
 Archive 
 
 
 
 
 
 
### Images

 
 
 Metropolitan Museum 
 
 Cleveland
 Museum of Art 
 
 
 
 
#### Featured

 
 
 All Images 
 
 Flickr Commons 
 
 
 Occupy Wall
 Street Flickr 
 
 Cover Art 
 
 USGS Maps 
 
 
 
 
 
#### Top

 
 
 NASA Images 
 
 Solar System
 Collection 
 
 Ames Research
 Center 
 
 
 
 
 
 
### Software

 
 
 Internet
 Arcade 
 
 Console Living Room 
 
 
 
 
#### Featured

 
 
 All Software 
 
 
 Old School
 Emulation 
 
 MS-DOS Games 
 
 
 Historical
 Software 
 
 Classic PC
 Games 
 
 Software
 Library 
 
 
 
 
 
#### Top

 
 
 Kodi
 Archive and Support File 
 
 Vintage
 Software 
 
 APK 
 
 MS-DOS 
 
 CD-ROM
 Software 
 
 CD-ROM
 Software Library 
 
 Software Sites 
 
 
 Tucows
 Software Library 
 
 Shareware
 CD-ROMs 
 
 Software
 Capsules Compilation 
 
 CD-ROM Images 
 
 
 ZX Spectrum 
 
 DOOM Level CD 
 
 
 
 
 
 
 
### Texts

 
 
 Open Library 
 
 American
 Libraries 
 
 
 
 
#### Featured

 
 
 All Texts 
 
 Smithsonian
 Libraries 
 
 FEDLINK (US) 
 
 Genealogy 
 
 Lincoln
 Collection 
 
 
 
 
 
#### Top

 
 
 American
 Libraries 
 
 Canadian
 Libraries 
 
 Universal
 Library 
 
 Project
 Gutenberg 
 
 Children's
 Library 
 
 Biodiversity
 Heritage Library 
 
 Books by
 Language 
 
 Additional
 Collections 
 
 
 
 
 
 
### Video

 
 
 TV News 
 
 Understanding
 9/11 
 
 
 
 
#### Featured

 
 
 All Video 
 
 Prelinger
 Archives 
 
 Democracy Now! 
 
 
 Occupy Wall
 Street 
 
 TV NSA Clip
 Library 
 
 
 
 
 
#### Top

 
 
 Animation
 & Cartoons 
 
 Arts & Music 
 
 
 Computers
 & Technology 
 
 Cultural
 & Academic Films 
 
 Ephemeral Films 
 
 
 Movies 
 
 News &
 Public Affairs 
 
 Spirituality
 & Religion 
 
 Sports Videos 
 
 Television 
 
 Videogame
 Videos 
 
 Vlogs 
 
 Youth Media 
 
 
 
 
 
 
 
 
 
 
 Search the history of more than 1 trillion
 web pages .
 
 
 
 
 
 
 
 
 
 
 
 Search the Wayback Machine 
 
 
 
 Search icon 
 An illustration of a magnifying
 glass. 
 
 

 
 
 
 
 
 
 
#### Mobile Apps

 
 
 
 Wayback Machine (iOS) 
 
 
 Wayback Machine (Android) 
 
 
 
#### Browser Extensions

 
 
 
 Chrome 
 
 
 Firefox 
 
 
 Safari 
 
 
 Edge 
 
 
 
 
 
#### Archive-It Subscription

 
 
 
 Explore the Collections 
 
 
 Learn More 
 
 
 Build Collections 
 
 
 
 
 
 
 
### Save Page Now

 Capture a web page as it appears now for use as a trusted
 citation in the future. 
 
 Enter a URL to save 
 
 
 
 Please enter a valid web address 
 
 
 
 
 
 
 
 
 About 
 
 Blog 
 
 Events 
 
 Projects 
 
 Help 
 
 Donate 
 
 Contact 
 
 Jobs 
 
 Volunteer 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 Sign up for free
 
 
 
 
 
 Log in
 
 
 
 
 
 
 

 
 
 
 
 
 
 Search metadata
 
 
 
 
 Search text contents
 
 
 
 
 Search TV news captions
 
 
 
 
 Search radio transcripts
 
 
 
 
 Search archived web sites
 
 
 Advanced Search 
 
 
 
 
 
 
 
 About 
 
 
 
 Blog 
 
 
 
 Events 
 
 
 
 Projects 
 
 
 
 Help 
 
 
 
 Donate 
 
 Donate icon 
 An illustration of a heart shape 
 
 
 
 
 
 
 
 Contact 
 
 
 
 Jobs 
 
 
 
 Volunteer 
 
 
 
 
 
 
 

 
 
 
 
 
 
 
 
 
 
 The Wayback Machine requires your browser to support JavaScript, please email info@archive.org if you have any questions about this.
 
 
 
 
 
 The Wayback Machine is an initiative of the
 Internet Archive ,
 a 501(c)(3) non-profit, building a digital library of
 Internet sites and other cultural artifacts in digital form.
 Other projects include
 Open Library &
 archive-it.org .
 
 
 Your use of the Wayback Machine is subject to the Internet Archive's
 Terms of Use .
