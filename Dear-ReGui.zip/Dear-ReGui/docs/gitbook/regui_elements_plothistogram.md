# Plothistogram

> Source: https://depso.gitbook.io/regui/elements/plothistogram

